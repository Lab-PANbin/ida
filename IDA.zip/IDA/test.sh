python test.py  --cuda --dataset 'target dataset'  --model_dir 'your model .pth path'



