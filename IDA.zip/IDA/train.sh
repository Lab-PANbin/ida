
python -u da_trainval_net.py --max_epochs 10 --cuda  --dataset_s 'source domain dataset' --dataset_t 'target domain dataset' --bs 1 